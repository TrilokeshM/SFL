from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

app = FastAPI()

class Todo(BaseModel):
    id: int
    title: str
    completed: bool = False

todos = []

@app.get('/todos', response_model=List[Todo])
def get_todos():
    return todos

@app.post('/todos', response_model=Todo)
def create_todo(todo: Todo):
    todos.append(todo)
    return todo
