# To-Do App

A simple FastAPI CRUD application.
