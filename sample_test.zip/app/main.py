from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.database import engine, SessionLocal
from app.models import Base, Todo

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Todo API")


class TodoCreate(BaseModel):
    title: str


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/todos")
def create_todo(payload: TodoCreate, db: Session = Depends(get_db)):
    todo = Todo(title=payload.title, done=False)
    db.add(todo)
    db.commit()
    db.refresh(todo)
    return todo


@app.get("/todos")
def list_todos(db: Session = Depends(get_db)):
    return db.query(Todo).all()


@app.put("/todos/{todo_id}/complete")
def complete_todo(todo_id: int, db: Session = Depends(get_db)):
    todo = db.query(Todo).filter(Todo.id == todo_id).first()
    if not todo:
        raise HTTPException(status_code=404, detail="Todo not found")
    todo.done = True
    db.commit()
    return todo
