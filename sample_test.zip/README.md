# Todo API

A tiny FastAPI + SQLAlchemy todo list service, used as a demo/test ZIP
for the Project Submission AI Analyzer.
